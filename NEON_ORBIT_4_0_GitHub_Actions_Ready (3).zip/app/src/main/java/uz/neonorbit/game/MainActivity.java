package uz.neonorbit.game;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import java.io.ByteArrayInputStream;

public class MainActivity extends Activity {
    private WebView game;
    private static final String GAME_URL = "file:///android_asset/neon_orbit.html";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8, 12, 27));
        getWindow().setNavigationBarColor(Color.rgb(8, 12, 27));
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        game = new WebView(this);
        game.setBackgroundColor(Color.rgb(8,12,27));
        WebSettings settings=game.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true); // bundled, offline game asset
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        game.setWebChromeClient(new WebChromeClient());
        game.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !GAME_URL.equals(request.getUrl().toString());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url=request.getUrl().toString();
                // All resources are inline in the local asset; disallow all external resources.
                if(url.equals(GAME_URL)) return super.shouldInterceptRequest(view, request);
                return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
            }
        });
        setContentView(game);
        game.loadUrl(GAME_URL);
    }
    @Override public void onBackPressed(){ if(game!=null)game.evaluateJavascript("window.neonPause&&window.neonPause()",null); }
    @Override protected void onPause(){
        if(game!=null){game.evaluateJavascript("window.neonPause&&window.neonPause()",null);game.onPause();}
        super.onPause();
    }
    @Override protected void onResume(){super.onResume();if(game!=null)game.onResume();}
    @Override protected void onDestroy(){if(game!=null){game.destroy();game=null;}super.onDestroy();}
}
