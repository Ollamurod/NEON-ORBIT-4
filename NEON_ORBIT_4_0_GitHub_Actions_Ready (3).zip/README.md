# NEON ORBIT 4.0 — Android

NEON ORBIT 4.0 is an offline mobile game: the Android application loads the bundled HTML5 game in an Android WebView.

## Online APK build using GitHub Actions

1. Create a new GitHub repository (e.g., `NEON-ORBIT-4`).
2. Extract this ZIP and upload **all files and folders from this directory**, including the hidden `.github` directory, to the **root** of that repository. Do not upload only the ZIP file.
3. Go to **Actions** → **Build NEON ORBIT 4.0 APK** → **Run workflow** → **Run workflow**. A push to `main` or `master` with source changes also starts the workflow.
4. After the green check appears, open the workflow run, scroll to **Artifacts**, and download `NEON-ORBIT-4-debug-APK`.
5. Extract the artifact ZIP. The file inside is `app-debug.apk`. Install it on your Android phone if you trust the file.

Important: APK builds are **not verified** until this workflow successfully runs in your own GitHub repo. This is a **debug** APK for testing, not a Play Store signed release.

## Project setup

- `app/src/main/assets/neon_orbit.html` — full playable game, works offline
- `app/src/main/java/uz/neonorbit/game/MainActivity.java` — Android WebView shell
- `.github/workflows/build-apk.yml` — automatic APK build pipeline
- `app/build.gradle` — Android Gradle Plugin app configuration
- Gradle 8.9, Android Gradle Plugin 8.7.3, Java 17, compile SDK 35

There is no Gradle wrapper in this source package. The workflow installs Gradle 8.9 automatically.

## Security

The build runs with repository read-only permissions, uses no custom secrets, and publishes only a debug APK artifact. For the first version, use a private repository if the game code should remain unpublished.
