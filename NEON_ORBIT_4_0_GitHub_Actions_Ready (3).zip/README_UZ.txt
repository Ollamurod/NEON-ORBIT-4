NEON ORBIT 4.0 — Android loyihasi
==================================
O'yin mutlaqo offlayn, HTML5 Canvas va Android WebView asosida.
Internetga ruxsat so'ralmaydi. O'yin holati WebView localStorage'da saqlanadi.

APK yig'ish:
1. ZIP faylni oching.
2. Android Studio'da NeonOrbit_Android_4 papkasini tanlang.
3. Android SDK Platform 35 va JDK 17 tayyor bo'lsin.
4. Android Studio Gradle 8.9'ni yuklab/sozlab olsin (loyihada wrapper mavjud emas).
5. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
6. debug APK: app/build/outputs/apk/debug/app-debug.apk.

Quyidagi muhitda APK build qilish va Android qurilmada ishga tushirish sinalmagan.
Internet talab qiladigan Gradle va SDK yuklash faqat dastlabki build uchun kerak.

Boshqarish: ekrandagi chap/o'ng tugmalar, qalqon va sekinlatish tugmalari.
Maxsus qora sharlar: KO'K rang bo'lagi bilan ushlang.
Bosqichlar: 1-50, har 5-bosqich boss; endless/time/precision alohida.
Do'kon: faqat o'yinda topilgan tangalar. Real to'lovlar yo'q.
Til, statistika, ochilgan bezaklar, natijalar localStorage'da saqlanadi.

Eslatma: ilova ma'lumotlarini tozalash barcha progressni yo'qotadi.
